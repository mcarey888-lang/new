# International catalogue alignment handoff

The international catalogue has been mapped to the existing `summit_data_engine` architecture. This package is staging material, not authorization for an immediate production import.

## Ready now

- 216 canonical mountain rows have valid geometry and map to `summit_data_engine.mountains`.
- 74 of those loadable rows are `verified`; 142 remain `needs_review`.
- Canonical identity uses `geonames:<id>`, then `wikidata:<id>`, then `summitready:<mountain_id>` as fallback.
- Summit elevation maps only to `mountains.elevation_m`.
- Route ascent remains route-specific and never maps to the Mountain entity.

## Blocked rows

- 37 verified mountain rows lack coordinates and therefore cannot satisfy the mandatory `mountains.geom` column. They are isolated in `mountains_blocked_missing_geometry.csv`.

## Required schema work before complete import

1. Make `mountain_source_records.prominence_m`, `col_height_m` and `grid_reference` nullable for non-DoBIH sources. Never substitute zero for missing facts.
2. Add a normalized `mountain_aliases` table linked to `mountains` and provenance/evidence.
3. Confirm the `rights_classification` value to use for reference-only factual URLs before loading `evidence_sources_staging.csv`.
4. Add a versioned route-facts structure for published distance, total ascent, start elevation and duration. Do not misuse `route_elevation_profiles`, which represents geometry/DEM-derived calculations.
5. Create one package-level `source_bundle` for this catalogue and preserve row-level publishers through `evidence_sources` and verification links.

## Safe implementation sequence

1. Create a checkpoint and migration.
2. Apply the nullable source-field and mountain-alias changes.
3. Add the route-facts structure.
4. Implement a dry-run importer with transaction rollback on any failed validation.
5. Resolve canonical keys against existing records before insert; never deduplicate by name alone.
6. Import evidence and verification links.
7. Import only the 216 geometry-complete Mountain rows.
8. Leave `needs_review` and blocked-coordinate records outside the trusted lookup tier.
9. Validate counts, foreign keys, duplicate canonical keys and a repeat-import no-op.
10. Change runtime lookup only after the import passes these checks.

## Corrected v4 identity and route evidence

- `INT-0092` was a shadow extraction of Denali (`Q130018`, GeoNames `5868589`) and is merged into verified `INT-0252`.
- Route-specific NPS evidence now supports `IR-0005` and `IR-0007`.
- Whitney distance is explicitly marked as a round trip derived from the published 17.1 km one-way route.
- Denali duration is the midpoint of the NPS 17–21 day average range.
