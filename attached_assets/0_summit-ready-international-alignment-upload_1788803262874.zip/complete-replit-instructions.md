# Summit Ready international catalogue schema and importer work

Create a checkpoint before making any changes.

Implement only the schema, importer and dry-run validation required to support the supplied international catalogue inside the existing `summit_data_engine` architecture. Do not change the live mountain lookup and do not perform a production import.

## Supplied files

- `canonical_mountains_staging.csv`
- `mountains_blocked_missing_geometry.csv`
- `mountain_source_records_staging.csv`
- `mountain_aliases_staging.csv`
- `evidence_sources_staging.csv`
- `routes_staging.csv`
- `field_mapping.csv`
- `schema_gaps.csv`
- `replit-alignment-handoff.md`

## Preserve the existing architecture

The canonical Mountain entity remains `summit_data_engine.mountains`. Do not create a second international mountain table. Do not import these records into `public.canonical_hills`, `public.cached_mountains` or `public.virtual_expeditions`. Do not modify or delete existing DoBIH records.

## Make source records internationally compatible

Create a migration allowing these `mountain_source_records` fields to be nullable:

- `prominence_m`
- `col_height_m`
- `grid_reference`

Unavailable values must remain null. Never substitute zero, empty measurements or invented data. Preserve all existing DoBIH validation rules and records.

## Add mountain aliases

Create a normalized `summit_data_engine.mountain_aliases` table containing:

- UUID primary key
- `mountain_id` foreign key to `summit_data_engine.mountains`
- alias name
- normalized alias used for lookup
- optional language or note
- verification status
- provenance version
- appropriate evidence/source relationship
- creation timestamp

Prevent duplicate normalized aliases for the same mountain and add an index supporting case-insensitive alias lookup. An alias must never create another mountain.

## Add versioned route facts

The existing `route_elevation_profiles` table represents geometry/DEM-derived calculations and is not appropriate for isolated published route metrics.

Add a versioned route-facts table linked to the existing route identity/definition architecture. It must support nullable:

- start name
- start elevation metres
- summit elevation metres
- distance kilometres
- total ascent metres
- total descent metres
- typical duration hours
- evidence/source relationship
- verification status
- QA flags
- provenance version
- creation timestamp

Leave a metric null whenever its source does not provide it.

Enforce this rule throughout the schema and importer:

- `mountains.elevation_m` is summit elevation above sea level.
- route `total_ascent_m` is cumulative ascent for one named route with a defined start.

Never map route ascent or trailhead-to-summit gain into `mountains.elevation_m`.

## Source bundle and evidence

Create one package-level `source_bundle` for `Summit Ready International Mountain Catalogue`, using the package hash and catalogue version for repeat-import identity.

Use `evidence_sources`, `mountain_verifications`, and their link table for individual authoritative publishers and factual URLs. Confirm the existing `rights_classification` enum values before loading evidence, and choose the valid value for reference-only factual citations. Do not invent an enum value unless a migration is genuinely necessary.

Preserve publisher, URL, retrieval date and field scope.

## Canonical identity and deduplication

Use the canonical-key order already supplied:

1. `geonames:<geonames_id>`
2. `wikidata:<wikidata_id>`
3. `summitready:<mountain_id>`

Never deduplicate by name alone.

Before insertion, compare canonical source key, GeoNames identity, coordinates within a conservative distance threshold, normalized canonical name and aliases, and potential geographic overlap with existing DoBIH records. Ambiguous matches enter the review queue instead of being merged automatically.

The importer must be idempotent. An identical repeat import must produce no changes.

## Import boundaries

The package contains:

- 217 mountains with valid required geometry
- 37 records isolated because coordinates are missing
- 4,203 staged aliases
- 487 staged evidence records
- 23 staged routes

Do not import `mountains_blocked_missing_geometry.csv`. Do not fabricate coordinates.

Within the geometry-complete set, verified records may enter the trusted catalogue after validation. `needs_review` records may be stored but must remain outside trusted lookup. Cho Oyu remains under review because the catalogue value of 8,188 m conflicts with a cited Chinese government value of 8,201 m.

## Importer requirements

Build a dedicated international-catalogue importer following the established DoBIH principles:

- strict header and required-field validation
- coordinate-range validation
- package/file hash validation
- deterministic source identity
- canonical-key collision detection
- immutable source-release records
- complete transaction rollback on critical failure
- dry-run mode
- repeat-import no-op verification
- explicit inserted, updated, unchanged, reviewed, blocked and failed counts

Do not silently skip malformed rows.

## Tests

Add tests covering:

- authoritative international mountain
- needs-review mountain
- multiple aliases and duplicate alias prevention
- multi-country mountain
- canonical-key collision
- potential DoBIH overlap
- missing geometry
- missing prominence and col height
- route identity without metrics
- route with sourced ascent
- proof that route ascent cannot update mountain elevation
- transaction rollback
- identical repeat import producing no changes

Run existing DoBIH importer tests as regression tests.

## Required stopping point

Run the international importer in dry-run mode only. Report:

- proposed migration
- exact files changed
- dry-run counts
- duplicate and match decisions
- review-queue records
- tests and results
- confirmation that all 21,576 DoBIH mountains remain unchanged
- confirmation that `/api/mountain-lookup` remains unchanged

Stop after schema implementation, importer implementation and successful dry-run validation. Do not run the production import and do not change lookup behaviour without further approval.
